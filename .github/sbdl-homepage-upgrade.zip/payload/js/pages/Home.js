export default {
    name: 'Home',
    data() {
        return {
            searchQuery: '',
            faqOpen: false,
            shortcutHelp: false,
            showBackToTop: false,
            sections: [
                { title: 'Demon List', description: 'Browse the ranked levels and see which demons make the list.', icon: '▤', to: '/' },
                { title: 'Leaderboard', description: 'Explore player rankings and points earned across SBDL.', icon: '♜', to: '/leaderboard' },
                { title: 'List History', description: 'Look back through previous rankings and changes to the list.', icon: '◷', to: '/history' },
                { title: 'Level Packs', description: 'Find packs and challenges to work through.', icon: '▦', to: '/packs' },
                { title: 'Achievements', description: 'See milestones and achievements available on the site.', icon: '✦', to: '/achievements' },
                { title: 'Games', description: 'Take a break with the SBDL mini-games.', icon: '◈', to: '/games' },
            ],
        };
    },
    computed: {
        filteredSections() {
            const query = this.searchQuery.trim().toLowerCase();
            if (!query) return this.sections;
            return this.sections.filter(section => `${section.title} ${section.description}`.toLowerCase().includes(query));
        },
    },
    mounted() {
        this._sbdlKeyHandler = event => {
            const tag = event.target && event.target.tagName;
            const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(tag) || (event.target && event.target.isContentEditable);
            if (event.key === '/' && !typing) {
                event.preventDefault();
                const search = this.$el.querySelector('.sbdl-home__search');
                if (search) search.focus();
            } else if (event.key === '?' && !typing) {
                this.shortcutHelp = !this.shortcutHelp;
            } else if (event.key === 'Escape') {
                this.shortcutHelp = false;
                if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
            }
        };
        this._sbdlScrollHandler = () => { this.showBackToTop = window.scrollY > 250; };
        document.addEventListener('keydown', this._sbdlKeyHandler);
        window.addEventListener('scroll', this._sbdlScrollHandler, { passive: true });
        this._sbdlScrollHandler();
    },
    beforeUnmount() {
        document.removeEventListener('keydown', this._sbdlKeyHandler);
        window.removeEventListener('scroll', this._sbdlScrollHandler);
    },
    methods: {
        async copySiteLink() {
            const button = this.$el.querySelector('.sbdl-home__copy');
            try {
                await navigator.clipboard.writeText(window.location.origin);
                if (button) button.textContent = 'Link copied!';
            } catch (_) {
                window.prompt('Copy the SBDL site link:', window.location.origin);
            }
        },
        goRandom() {
            const options = this.sections.filter(section => section.to !== '/');
            const current = this.$route && this.$route.path;
            const available = options.filter(section => section.to !== current);
            const choice = (available.length ? available : options)[Math.floor(Math.random() * (available.length || options.length))];
            if (choice) this.$router.push(choice.to);
        },
        goRecent() {
            let recent = '';
            try { recent = window.sessionStorage.getItem('sbdl-recent-section') || ''; } catch (_) { /* storage may be disabled */ }
            if (recent && recent !== '/home' && this.sections.some(section => section.to === recent)) {
                this.$router.push(recent);
            } else {
                window.alert('Visit a section first and you can return to it during this session.');
            }
        },
        rememberSection(path) {
            if (!path || path === '/home') return;
            try { window.sessionStorage.setItem('sbdl-recent-section', path); } catch (_) { /* storage may be disabled */ }
        },
        clearSearch() {
            this.searchQuery = '';
            const search = this.$el.querySelector('.sbdl-home__search');
            if (search) search.focus();
        },
        backToTop() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        },
    },
    watch: {
        '$route.path'(path) { this.rememberSection(path); },
    },
    template: `
        <main class="sbdl-home">
            <section class="sbdl-home__hero">
                <div class="sbdl-home__hero-copy">
                    <p class="sbdl-home__eyebrow"><span aria-hidden="true"></span> SUBERBOYS DEMONLIST</p>
                    <h1>Welcome to the <em>SBDL.</em></h1>
                    <p class="sbdl-home__intro">A list for the hardest Geometry Dash demons made by the Suberboys community. Explore the rankings, check player points, and find your next challenge.</p>
                    <div class="sbdl-home__actions">
                        <router-link class="sbdl-home__button sbdl-home__button--primary" to="/">Browse the Demon List <span aria-hidden="true">→</span></router-link>
                        <router-link class="sbdl-home__button sbdl-home__button--secondary" to="/leaderboard">Player leaderboard</router-link>
                    </div>
                    <div class="sbdl-home__tools" aria-label="Homepage tools">
                        <input v-model="searchQuery" class="sbdl-home__search" type="search" placeholder="Find a section..." aria-label="Search SBDL sections">
                        <button class="sbdl-home__tool-button" type="button" @click="clearSearch">Clear search</button>
                        <button class="sbdl-home__tool-button sbdl-home__copy" type="button" @click="copySiteLink">Copy site link</button>
                        <button class="sbdl-home__tool-button" type="button" @click="goRandom">Surprise me</button>
                        <button class="sbdl-home__tool-button" type="button" @click="goRecent">Recently visited</button>
                    </div>
                    <p class="sbdl-home__shortcut-help">Press <kbd>/</kbd> to search or <kbd>?</kbd> for shortcuts.</p>
                </div>
                <div class="sbdl-home__mark" aria-hidden="true">
                    <div class="sbdl-home__mark-inner"><span>S</span></div>
                    <p>SUBERBOYS<br>DEMONLIST</p>
                </div>
            </section>
            <section class="sbdl-home__section" aria-labelledby="sbdl-home-explore-title">
                <p class="sbdl-home__kicker">EXPLORE SBDL</p>
                <h2 id="sbdl-home-explore-title">Everything starts here.</h2>
                <p class="sbdl-home__section-intro">Jump into the list, check the leaderboard, or explore more of the community features.</p>
                <div class="sbdl-home__cards">
                    <router-link v-for="section in filteredSections" :key="section.to" class="sbdl-home__card" :to="section.to">
                        <span class="sbdl-home__card-icon" aria-hidden="true">{{ section.icon }}</span>
                        <h3>{{ section.title }} <span aria-hidden="true">↗</span></h3>
                        <p>{{ section.description }}</p>
                    </router-link>
                    <p v-if="filteredSections.length === 0" class="sbdl-home__no-results">No sections match that search.</p>
                </div>
            </section>
            <section class="sbdl-home__section sbdl-home__extras" aria-labelledby="sbdl-home-extras-title">
                <p class="sbdl-home__kicker">EXTRAS</p>
                <h2 id="sbdl-home-extras-title">A few handy tools.</h2>
                <div class="sbdl-home__cards sbdl-home__extra-cards">
                    <article class="sbdl-home__card"><span class="sbdl-home__card-icon">×</span><h3>Clear search</h3><p>Reset the section search and show every link again.</p><button class="sbdl-home__inline-button" type="button" @click="clearSearch">Clear search</button></article>
                    <article class="sbdl-home__card"><span class="sbdl-home__card-icon">↗</span><h3>Copy site link</h3><p>Copy the SBDL address to share with friends.</p><button class="sbdl-home__inline-button sbdl-home__copy" type="button" @click="copySiteLink">Copy link</button></article>
                    <article class="sbdl-home__card"><span class="sbdl-home__card-icon">↝</span><h3>Surprise me</h3><p>Jump to a randomly chosen existing section.</p><button class="sbdl-home__inline-button" type="button" @click="goRandom">Pick a section</button></article>
                    <article class="sbdl-home__card"><span class="sbdl-home__card-icon">◷</span><h3>Recently visited</h3><p>Return to the last section you opened this session.</p><button class="sbdl-home__inline-button" type="button" @click="goRecent">Go to recent</button></article>
                    <article class="sbdl-home__card"><span class="sbdl-home__card-icon">?</span><h3>Quick FAQ</h3><p>Answers to common questions, without opening another page.</p><button class="sbdl-home__inline-button" type="button" @click="faqOpen = !faqOpen">{{ faqOpen ? 'Hide answers' : 'Show answers' }}</button><div v-if="faqOpen" class="sbdl-home__faq"><p><strong>What is SBDL?</strong><br>A list for hard Geometry Dash demons made by the Suberboys community.</p><p><strong>Where do I find player points?</strong><br>Open the existing Player Leaderboard page.</p></div></article>
                    <article class="sbdl-home__card"><span class="sbdl-home__card-icon">⌨</span><h3>Keyboard shortcuts</h3><p>Use <kbd>/</kbd> to focus search, <kbd>?</kbd> to show help, and <kbd>Esc</kbd> to close it.</p><button class="sbdl-home__inline-button" type="button" @click="shortcutHelp = !shortcutHelp">{{ shortcutHelp ? 'Hide shortcuts' : 'Show shortcuts' }}</button><p v-if="shortcutHelp" class="sbdl-home__faq">Press / to search. Press ? to toggle this help. Press Esc to close it.</p></article>
                    <article class="sbdl-home__card"><span class="sbdl-home__card-icon">↑</span><h3>Back to top</h3><p>Scroll down and use the button in the corner to return to the top.</p><button class="sbdl-home__inline-button" type="button" @click="backToTop">Back to top now</button></article>
                </div>
            </section>
            <button v-if="showBackToTop" class="sbdl-home__back-top" type="button" @click="backToTop" aria-label="Back to top">↑ Top</button>
        </main>
    `,
};

#!/usr/bin/env python3
"""Install the SBDL homepage, navigation, and homepage tools."""
from __future__ import annotations
import argparse
import shutil
from pathlib import Path


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"Expected exactly one integration anchor in {label}; found {count}: {old[:100]!r}")
    return text.replace(old, new, 1)


def copy_payload(root: Path, payload: Path) -> None:
    if not payload.is_dir():
        raise SystemExit(f"Payload folder not found: {payload}")
    for source in payload.rglob('*'):
        if source.is_file():
            target = root / source.relative_to(payload)
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists() or target.read_bytes() != source.read_bytes():
                shutil.copy2(source, target)


def patch_index(root: Path) -> None:
    path = root / 'index.html'
    text = path.read_text(encoding='utf-8')
    css_link = '        <link rel="stylesheet" type="text/css" href="/css/pages/home.css" />'
    if css_link not in text:
        anchor = '        <link rel="stylesheet" type="text/css" href="/css/pages/list.css" />'
        text = replace_once(text, anchor, css_link + '\n' + anchor, str(path))
    old_logo = """            <div class="logo">
                <h2>SBDL</h2>
                <p>v1.0.0</p>
            </div>"""
    new_logo = """            <router-link class="logo" to="/home" aria-label="SBDL homepage" title="Go to homepage">
                <h2>SBDL</h2>
                <p>v1.0.0</p>
            </router-link>"""
    if new_logo not in text:
        text = replace_once(text, old_logo, new_logo, str(path))
    path.write_text(text, encoding='utf-8', newline='\n')


def patch_routes(root: Path) -> None:
    path = root / 'js/routes.js'
    text = path.read_text(encoding='utf-8')
    import_line = "import Home from './pages/Home.js';"
    if import_line not in text:
        anchor = "import List from './pages/List.js';"
        text = replace_once(text, anchor, anchor + '\n' + import_line, str(path))
    route_line = "    { path: '/home', component: Home },"
    if route_line not in text:
        anchor = "    { path: '/', component: List },"
        text = replace_once(text, anchor, anchor + '\n' + route_line, str(path))
    path.write_text(text, encoding='utf-8', newline='\n')


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default='.')
    parser.add_argument('--payload', required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    payload = Path(args.payload).resolve()
    required = [root / 'index.html', root / 'js/routes.js', root / 'js/pages/List.js']
    missing = [str(p.relative_to(root)) for p in required if not p.is_file()]
    if missing:
        raise SystemExit('Files required to safely install this update are missing: ' + ', '.join(missing))
    for item in [payload / 'js/pages/Home.js', payload / 'css/pages/home.css']:
        if not item.is_file():
            raise SystemExit('Payload is missing required file: ' + str(item.relative_to(payload)))
    copy_payload(root, payload)
    patch_index(root)
    patch_routes(root)
    print('Installed SBDL homepage at /home and linked the SBDL header logo to it.')
    print('Added eight homepage tools. The existing DemonList remains at /.')

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Idempotently integrate Suberboys competition-platform enhancements."""
from __future__ import annotations
import argparse
import re
import shutil
from pathlib import Path


def replace_once(text: str, old: str, new: str, filename: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"Expected exactly one integration anchor in {filename}, found {count}: {old[:100]!r}")
    return text.replace(old, new, 1)


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def patch_worker(root: Path) -> None:
    path = root / "worker.js"
    text = path.read_text(encoding="utf-8")
    import_line = 'import { handleCompetitionPlatformRequest } from "./competition-platform-worker.js";'
    if import_line not in text:
        anchor = 'import { handleCommunityRequest, captureCommunitySnapshot, ensureCommunitySchema } from "./community-features-worker.js";'
        text = replace_once(text, anchor, anchor + "\n" + import_line, str(path))

    condition = '''                url.pathname.startsWith("/api/community/") ||
                url.pathname === "/api/rank-history" ||
                url.pathname === "/api/weekly-quests"'''
    updated_condition = '''                url.pathname.startsWith("/api/community/") ||
                url.pathname.startsWith("/api/competition/") ||
                url.pathname === "/api/rank-history" ||
                url.pathname === "/api/weekly-quests"'''
    if 'url.pathname.startsWith("/api/competition/")' not in text:
        text = replace_once(text, condition, updated_condition, str(path))

    route_marker = "            const rankHistoryQuestResponse = await handleRankHistoryQuestRequest("
    if "const competitionResponse = await handleCompetitionPlatformRequest" not in text:
        route_insert = '''            const competitionResponse = await handleCompetitionPlatformRequest(
                request, env, url, currentUser, captureDailyRankSnapshot
            );
            if (competitionResponse) return competitionResponse;
'''
        text = replace_once(text, route_marker, route_insert + route_marker, str(path))
    write_text(path, text)


def patch_main(root: Path) -> None:
    path = root / "js/main.js"
    text = path.read_text(encoding="utf-8")
    imports = [
        "import NotificationsBell from './components/NotificationsBell.js';",
        "import PlayerGoalsWidget from './components/PlayerGoalsWidget.js';",
        "import CompetitionSeasonWidget from './components/CompetitionSeasonWidget.js';",
        "import CompetitionAdminTools from './components/CompetitionAdminTools.js';",
    ]
    if "from './components/NotificationsBell.js'" not in text:
        text = replace_once(text, "import routes from './routes.js';", "import routes from './routes.js';\n" + "\n".join(imports), str(path))
    registrations = '''app.component('notifications-bell', NotificationsBell);
app.component('player-goals-widget', PlayerGoalsWidget);
app.component('competition-season-widget', CompetitionSeasonWidget);
app.component('competition-admin-tools', CompetitionAdminTools);'''
    if "app.component('notifications-bell'" not in text:
        text = replace_once(text, "app.use(router);", "app.use(router);\n\n" + registrations + "\n", str(path))
    write_text(path, text)


def patch_index(root: Path) -> None:
    path = root / "index.html"
    text = path.read_text(encoding="utf-8")
    css_link = '<link rel="stylesheet" type="text/css" href="/css/components/competition-platform.css" />'
    if "/css/components/competition-platform.css" not in text:
        pattern = re.compile(r'(?m)^(?P<indent>[ \t]*)<link rel="stylesheet" type="text/css" href="/css/components/nav\.css" />[ \t]*$')
        matches = list(pattern.finditer(text))
        if matches:
            m = matches[0]
            replacement = f'{m.group("indent")}{css_link}\n{m.group(0)}'
            text = text[:m.start()] + replacement + text[m.end():]
        else:
            text = replace_once(text, "    </head>", f"    {css_link}\n    </head>", str(path))
    if "<notifications-bell></notifications-bell>" not in text:
        pattern = re.compile(r'(?m)^(?P<indent>[ \t]*)<div class="nav__actions">[ \t]*$')
        matches = list(pattern.finditer(text))
        if len(matches) != 1:
            raise SystemExit(f"Expected one nav__actions element in {path}, found {len(matches)}")
        m = matches[0]
        indent = m.group("indent")
        replacement = f'{indent}<div class="nav__actions">\n{indent}    <notifications-bell></notifications-bell>'
        text = text[:m.start()] + replacement + text[m.end():]
    write_text(path, text)


def patch_leaderboard(root: Path) -> None:
    path = root / "js/pages/Leaderboard.js"
    text = path.read_text(encoding="utf-8")
    if "movementByName:" not in text:
        text = replace_once(text, "    avatarProfiles: [],", "    avatarProfiles: [],\n    movementByName: {},\n    movementSnapshotDate: '',", str(path))

    if "<competition-season-widget" not in text:
        pattern = re.compile(r'(?m)^(?P<indent>[ \t]*)<div class="leaderboard-controls">')
        matches = list(pattern.finditer(text))
        if len(matches) != 1:
            raise SystemExit(f"Expected one leaderboard-controls block in {path}, found {len(matches)}")
        m = matches[0]
        indent = m.group("indent")
        replacement = f'{indent}<competition-season-widget :players="leaderboard"></competition-season-widget>\n{indent}<player-goals-widget></player-goals-widget>\n{m.group(0)}'
        text = text[:m.start()] + replacement + text[m.end():]

    old_rank = '<p class="type-label-lg">#{{ i + 1 }}</p>'
    new_rank = '''<p class="type-label-lg">#{{ i + 1 }}
                <span v-if="sortBy === 'points' && movementFor(ientry.user, i + 1).change !== null"
                    class="competition-rank-change"
                    :class="{ 'is-up': movementFor(ientry.user, i + 1).change > 0, 'is-down': movementFor(ientry.user, i + 1).change < 0, 'is-flat': movementFor(ientry.user, i + 1).change === 0 }"
                    :title="'Previous rank: #' + movementFor(ientry.user, i + 1).previousRank">
                    {{ movementFor(ientry.user, i + 1).change > 0 ? '▲ ' + movementFor(ientry.user, i + 1).change : (movementFor(ientry.user, i + 1).change < 0 ? '▼ ' + Math.abs(movementFor(ientry.user, i + 1).change) : '—') }}
                </span>
            </p>'''
    if "movementFor(ientry.user" not in text:
        text = replace_once(text, old_rank, new_rank, str(path))

    if "'/api/competition/movements'" not in text:
        pattern = re.compile(r'(?m)^(?P<assignment>[ \t]*)this\.avatarProfiles = result\.profiles \|\| \[\];[ \t]*\n(?P<ifclose>[ \t]*)\}[ \t]*\n(?P<catch>[ \t]*\} catch \(error\) \{)')
        matches = list(pattern.finditer(text))
        if len(matches) != 1:
            raise SystemExit(f"Could not safely find avatar-profile load block in {path}; found {len(matches)}")
        m = matches[0]
        indent = m.group("ifclose")
        movement = (
            f"{indent}try {{\n"
            f"{indent}    const movementResponse = await fetch('/api/competition/movements', {{ credentials: 'same-origin', cache: 'no-store' }});\n"
            f"{indent}    if (movementResponse.ok) {{\n"
            f"{indent}        const movementResult = await movementResponse.json();\n"
            f"{indent}        this.movementByName = movementResult.previousRanks || {{}};\n"
            f"{indent}        this.movementSnapshotDate = movementResult.previousDate || '';\n"
            f"{indent}    }}\n"
            f"{indent}}} catch (movementError) {{\n"
            f"{indent}    console.warn('Could not load rank movement:', movementError);\n"
            f"{indent}}}\n"
        )
        replacement = f"{m.group('assignment')}this.avatarProfiles = result.profiles || [];\n{m.group('ifclose')}}}\n{movement}{m.group('catch')}"
        text = text[:m.start()] + replacement + text[m.end():]

    if "movementFor(playerName, currentRank)" not in text:
        pattern = re.compile(r'(?m)^(?P<indent>[ \t]*)methods: \{\n(?P<method_indent>[ \t]*)countryFlag,')
        matches = list(pattern.finditer(text))
        if len(matches) != 1:
            raise SystemExit(f"Could not find leaderboard methods anchor in {path}; found {len(matches)}")
        m = matches[0]
        base = m.group("indent")
        mi = m.group("method_indent")
        method = (
            f"{base}methods: {{\n"
            f"{mi}movementFor(playerName, currentRank) {{\n"
            f"{mi}    const key = String(playerName || '').trim().toLocaleLowerCase('en');\n"
            f"{mi}    const previous = this.movementByName[key];\n"
            f"{mi}    if (!previous || !Number.isFinite(Number(previous.rank))) return {{ change: null, previousRank: null }};\n"
            f"{mi}    return {{ change: Number(previous.rank) - Number(currentRank), previousRank: Number(previous.rank) }};\n"
            f"{mi}}},\n"
            f"{mi}countryFlag,"
        )
        text = text[:m.start()] + method + text[m.end():]
    write_text(path, text)


def patch_profile(root: Path) -> None:
    path = root / "js/pages/Profile.js"
    text = path.read_text(encoding="utf-8")
    if "<player-goals-widget" not in text:
        import re
        pattern = re.compile(r'(\s*</section>\s*)(<div class="avatar-upload">)')
        matches = list(pattern.finditer(text))
        if not matches:
            raise SystemExit(f"Could not find profile hero closing section in {path}")
        m = matches[0]
        insert = '\n            <template v-if="!loading && user">\n                <player-goals-widget></player-goals-widget>\n            </template>\n\n '
        text = text[:m.start()] + m.group(1) + insert + m.group(2) + text[m.end():]
    write_text(path, text)


def patch_assetsignore(root: Path) -> None:
    path = root / ".assetsignore"
    text = path.read_text(encoding="utf-8") if path.exists() else "# Server-side modules should not be served as public static assets.\n"
    additions = [
        "/competition-platform-worker.js",
        "/community-features-worker.js",
        "/rank-history-quests-worker.js",
    ]
    missing = [item for item in additions if item not in text.splitlines()]
    if missing:
        if text and not text.endswith("\n"):
            text += "\n"
        text += "\n# Server-side Worker modules (bundled into worker.js, not public assets)\n"
        text += "\n".join(missing) + "\n"
    write_text(path, text)


def patch_admin(root: Path) -> None:
    path = root / "js/pages/Admin.js"
    text = path.read_text(encoding="utf-8")
    if "<competition-admin-tools" not in text:
        text = replace_once(text, "                <!-- DASHBOARD -->", "                <!-- DASHBOARD -->\n                <competition-admin-tools></competition-admin-tools>", str(path))
    write_text(path, text)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--payload", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    payload = Path(args.payload).resolve()
    required = [root / "worker.js", root / "js/main.js", root / "index.html",
                root / "js/pages/Leaderboard.js", root / "js/pages/Profile.js", root / "js/pages/Admin.js"]
    missing = [str(p.relative_to(root)) for p in required if not p.is_file()]
    if missing:
        raise SystemExit("Repository files required for a safe install are missing: " + ", ".join(missing))
    if not (payload / "competition-platform-worker.js").is_file():
        raise SystemExit("The package is missing payload/competition-platform-worker.js")

    for source in payload.rglob("*"):
        if source.is_file():
            target = root / source.relative_to(payload)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and target.read_bytes() == source.read_bytes():
                continue
            shutil.copy2(source, target)

    patch_worker(root)
    patch_main(root)
    patch_index(root)
    patch_leaderboard(root)
    patch_profile(root)
    patch_admin(root)
    patch_assetsignore(root)
    print("Competition platform installed into existing pages.")
    print("Added: navbar notifications, season selector, goals widgets, rank movement and admin operations.")
    print("No new page routes or R2 bucket were added.")

if __name__ == "__main__":
    main()

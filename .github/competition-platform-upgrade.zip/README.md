# Suberboys Competition Platform Update

This bundle adds four major player-facing features and competition operations to the existing Suberboys Demon List site **without adding new page routes**:

1. Navbar notification bell and unread dropdown. Notifications are user-scoped. Rank/point changes, weekly quest/secret achievement completions that have been saved, and admin announcements are surfaced.
2. Seasonal competition selector inside the existing leaderboard. Season scores are calculated from real saved snapshots; no historical ranks are fabricated.
3. Personal next-rank goal widget inside both the existing Profile and Leaderboard pages.
4. Rank movement badges inside the current leaderboard, based on the previous stored daily snapshot and shown in points sort mode.
5. Admin operations panel embedded in the current Admin page: platform metrics, broadcast announcements, season creation and an audit of actions performed through these new controls. Existing admin permissions and tools are preserved.

No R2 binding or new paid storage is used. The Worker lazily creates the three new tables in the existing D1 database on first API use. A SQL migration is also included at `payload/migrations/0006_competition_platform.sql` for tracking/versioning in the repository.

## Install without a terminal

1. Extract `suberboys-competition-platform-release.zip` on your PC.
2. On GitHub, upload the inner file `competition-platform-upgrade.zip` into the repository's `.github/` folder and commit it to `main`.
3. Upload `install-competition-platform.yml` into `.github/workflows/` and commit it to `main`.
4. Go to Actions → **Install Competition Platform Upgrade** → Run workflow. Set **Confirm install** to `true`, then run it.
5. Inspect the run. The workflow checks JS syntax, validates the D1 migration SQL, runs the idempotent integration, then commits to `main`. Cloudflare deploy runs only after the repository changes reach the normal deployment trigger.
6. When Cloudflare reports a successful deployment, refresh the site with Ctrl+F5.

If anything fails, open the failed step and use the actual error log. The workflow intentionally fails if an expected integration anchor differs, instead of silently overwriting source code.

## Limits and behaviour

- Movement notifications require at least two stored daily rank snapshots to calculate a meaningful delta.
- Rank history and seasonal charts are based on actual snapshots going forward; older data isn't backfilled or invented.
- The personal goals widget requires the signed-in account to have linked a leaderboard identity.
- The admin panel's broadcast creates in-app notifications only; it does not send emails.
- The new admin endpoints use the existing authenticated account and `is_admin` check. Audit rows track the broadcast and season-management actions added here.
- The package has not been deployed to the live site by its author. Review GitHub Actions and Cloudflare deployment results after running it.

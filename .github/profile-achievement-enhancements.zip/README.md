# Suberboys Demon List — Achievement card upgrade

This patch updates the public player showcase achievement section.

## Changes

- Achievement cards and tier labels use their achievement tier colour: Bronze, Silver, Gold, Diamond, Platinum, or Legendary.
- Adds a completion bar showing unlocked achievements out of the total available.
- Adds a search box for unlocked achievements.
- Adds tier filter buttons with counts.
- Adds a Show all / Show fewer control when more than 12 achievements match.
- Keeps the existing page, layout, theme and responsive styles; no new database migration is required.

## Install without a terminal

1. Upload `profile-achievement-enhancements.zip` to the `.github` folder in your GitHub repository (not inside `.github/workflows`).
2. Upload `apply-achievement-enhancements.yml` to `.github/workflows`.
3. Commit both files to `main`.
4. Open Actions → **Apply Achievement Enhancements** → Run workflow. Leave the confirmation input set to `yes`.
5. After the workflow completes and the site's normal Cloudflare deployment succeeds, refresh a public player page with Ctrl+F5.

The workflow replaces only `js/pages/PlayerShowcase.js` and `css/pages/player-showcase.css`, then validates and commits those two files. It does not change the Worker, D1 schema, or profile customisation settings.

# Rank History + Weekly Quests — Suberboys Demon List

This package adds two features in one update:

- **Rank History** (`/#/history`) displays saved daily global rank and points, a rank/points chart, best saved rank, and recent snapshots.
- **Weekly Quests & Secret Achievements** (`/#/quests`) requires a logged-in account linked to a leaderboard identity. Weekly progress and hidden unlocks are stored privately per player in D1.

The integration script is idempotent. It adds the page files, Vue routes, nav links, API handler, daily cron, and asset exclusions without replacing the rest of the Worker.

## Install without a terminal

1. In Cloudflare Dashboard, open **Storage & databases → D1 → `suberboys-accounts` → Console**.
2. Open `migrations/0004_rank_history_quests.sql` and run its SQL. If the console accepts only one statement at a time, run each `CREATE TABLE` and `CREATE INDEX` statement separately. Do this **before** running the GitHub Actions installer.
3. Upload `rank-history-quests-upgrade.zip` from the outer ZIP into the repository's `.github/` folder and commit it to `main`.
4. Upload `install-rank-history-quests.yml` into `.github/workflows/` and commit it to `main`.
5. Open **Actions → Install Rank History and Quests → Run workflow**, choose `yes` for the confirmation, then run the workflow.
6. When it succeeds and Cloudflare deploys, refresh the website. With Vue hash routing, the pages are `/#/history` and `/#/quests`.

The installer updates `worker.js`, `js/routes.js`, `index.html`, `wrangler.jsonc`, `.assetsignore`, and adds the required JS/CSS/SQL files. It adds a daily `0 0 * * *` (UTC) Worker Cron Trigger so the rank snapshots continue being captured even when nobody opens the history page.

## Important behaviour

- Rank history begins on the first successful snapshot after installation; it cannot recreate historical data from before it was installed.
- Points and positions are reconstructed from the site's published list and level JSON using the site's current `score()` and pack definitions.
- The weekly quests use changes between the first saved snapshot of the UTC week and later daily snapshots. They do not detect changes retroactively before snapshots existed.
- Weekly quest pages require login and a linked leaderboard identity. The rank-history page uses public leaderboard information.
- Daily snapshots are retained for up to 730 days. Snapshots and quest data are stored in the existing D1 database; no R2 bucket is required.

## If installation fails

The workflow stops instead of overwriting a file when an expected anchor is missing. Open the failed Actions run and share the error text. If `wrangler.jsonc` contains JSONC comments and fails JSON parsing, the installer asks for a manual adjustment instead of rewriting it.

#!/usr/bin/env python3
"""Idempotently integrate Rank History + Weekly Quests into Suberboys Demon List."""
from __future__ import annotations
import argparse
import json
import re
import shutil
import sys
from pathlib import Path


def fail(message: str) -> None:
    raise SystemExit(f"Profile feature installer stopped safely: {message}")


def read_text(path: Path) -> str:
    if not path.is_file():
        fail(f"required file not found: {path.relative_to(ROOT)}")
    return path.read_text(encoding="utf-8")


def write_if_changed(path: Path, text: str) -> bool:
    if path.is_file() and path.read_text(encoding="utf-8") == text:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")
    return True


def patch_worker() -> None:
    path = ROOT / "worker.js"
    text = read_text(path)
    import_line = 'import { handleSubmissionRoute } from "./submission-routes.js";'
    new_import = 'import { handleRankHistoryQuestRequest, captureDailyRankSnapshot } from "./rank-history-quests-worker.js";'
    if "handleRankHistoryQuestRequest" not in text:
        if text.count(import_line) != 1:
            fail('worker.js import anchor changed; no files were partially patched. Restore the expected submission-routes import and retry.')
        text = text.replace(import_line, import_line + "\n" + new_import, 1)

    route_block = '''            const rankHistoryQuestResponse = await handleRankHistoryQuestRequest(
                request, env, url, currentUser
            );
            if (rankHistoryQuestResponse) return rankHistoryQuestResponse;

'''
    if "const rankHistoryQuestResponse = await handleRankHistoryQuestRequest(" not in text:
        marker = "            // Register an account."
        if text.count(marker) != 1:
            fail('worker.js account-route anchor changed; no files were partially patched. Please send the current worker.js to adapt the installer.')
        text = text.replace(marker, route_block + marker, 1)

    if "async scheduled(controller, env, ctx)" not in text:
        endings = "    }\n};"
        if not text.rstrip().endswith(endings):
            fail('worker.js does not end with the expected Worker export; no files were partially patched. Please send the current file.')
        trimmed = text.rstrip()
        trimmed = trimmed[:-len(endings)] + '''    },
    async scheduled(controller, env, ctx) {
        ctx.waitUntil(
            captureDailyRankSnapshot(env, new Date(controller.scheduledTime)).catch(error => {
                console.error("Daily rank-history snapshot failed:", error?.stack || error);
            })
        );
    }
};
'''
        text = trimmed
    write_if_changed(path, text)


def patch_routes() -> None:
    path = ROOT / "js/routes.js"
    text = read_text(path)
    imports = [
        "import RankHistory from './pages/RankHistory.js';",
        "import WeeklyQuests from './pages/WeeklyQuests.js';",
    ]
    if "import RankHistory from './pages/RankHistory.js';" not in text:
        anchor = "import PlayerShowcase from './pages/PlayerShowcase.js';"
        if anchor not in text:
            anchor = "import Profile from './pages/Profile.js';"
        if anchor not in text:
            fail('js/routes.js has no known page-import anchor; no files were partially patched.')
        text = text.replace(anchor, anchor + "\n" + "\n".join(imports), 1)
    elif "import WeeklyQuests from './pages/WeeklyQuests.js';" not in text:
        fail('routes.js contains a partial feature import; restore both imports or send the file for repair.')

    if "path: '/history'" not in text:
        marker = "    { path: '/achievements', component: Achievements },"
        if text.count(marker) != 1:
            fail('js/routes.js achievements route anchor changed; no files were partially patched.')
        text = text.replace(marker, marker + "\n    { path: '/history', component: RankHistory },\n    { path: '/quests', component: WeeklyQuests },", 1)
    elif "path: '/quests'" not in text:
        fail('routes.js already has a history route but not a quests route; please send routes.js for repair.')
    write_if_changed(path, text)


def patch_html() -> None:
    path = ROOT / "index.html"
    text = read_text(path)
    links = [
        '        <link rel="stylesheet" href="/css/pages/rank-history.css" />',
        '        <link rel="stylesheet" href="/css/pages/weekly-quests.css" />',
    ]
    if "/css/pages/rank-history.css" not in text:
        anchor = '        <link rel="stylesheet" href="/css/pages/player-showcase.css" />'
        if anchor not in text:
            fail('index.html player-showcase stylesheet anchor changed; no files were partially patched.')
        text = text.replace(anchor, anchor + "\n" + "\n".join(links), 1)
    elif "/css/pages/weekly-quests.css" not in text:
        fail('index.html contains a partial feature stylesheet setup; please send index.html for repair.')

    if 'to="/history"' not in text:
        pattern = re.compile(r'<router-link class="nav__tab" to="/achievements">.*?</router-link>', re.S)
        match = pattern.search(text)
        if not match:
            fail('index.html achievements navigation anchor changed; no files were partially patched.')
        nav = '''
                <router-link class="nav__tab" to="/history">
                    <span class="type-label-lg">History</span>
                </router-link>
                <router-link class="nav__tab" to="/quests">
                    <span class="type-label-lg">Quests</span>
                </router-link>'''
        text = text[:match.end()] + nav + text[match.end():]
    elif 'to="/quests"' not in text:
        fail('index.html already has History navigation but not Quests; please send index.html for repair.')
    write_if_changed(path, text)


def patch_wrangler() -> None:
    path = ROOT / "wrangler.jsonc"
    text = read_text(path)
    try:
        config = json.loads(text)
    except json.JSONDecodeError as error:
        fail(f'wrangler.jsonc is not plain JSON ({error}). It may contain JSONC comments; please send the current file so its formatting can be preserved.')

    bindings = [item.get("binding") for item in config.get("d1_databases", []) if isinstance(item, dict)]
    if "db" not in bindings:
        fail('wrangler.jsonc does not contain the expected D1 binding "db".')
    if config.get("assets", {}).get("binding") != "ASSETS":
        fail('wrangler.jsonc does not contain the expected static-assets binding "ASSETS".')

    triggers = config.setdefault("triggers", {})
    if not isinstance(triggers, dict):
        fail('wrangler.jsonc has a non-object triggers setting; please review it manually.')
    crons = triggers.setdefault("crons", [])
    if not isinstance(crons, list):
        fail('wrangler.jsonc triggers.crons must be an array.')
    if "0 0 * * *" not in crons:
        crons.append("0 0 * * *")
    write_if_changed(path, json.dumps(config, indent=2, ensure_ascii=False) + "\n")


def patch_assetsignore() -> None:
    path = ROOT / ".assetsignore"
    text = path.read_text(encoding="utf-8") if path.is_file() else ""
    lines = text.splitlines()
    if "rank-history-quests-worker.js" not in lines:
        lines.append("rank-history-quests-worker.js")
    if not path.is_file():
        for item in [".git/", ".github/", ".wrangler/", "worker.js", "wrangler.jsonc", "migrations/", ".assetsignore"]:
            if item not in lines:
                lines.append(item)
    write_if_changed(path, "\n".join(lines).rstrip() + "\n")


def copy_payload(payload: Path) -> None:
    mapping = {
        "rank-history-quests-worker.js": "rank-history-quests-worker.js",
        "js/pages/RankHistory.js": "js/pages/RankHistory.js",
        "js/pages/WeeklyQuests.js": "js/pages/WeeklyQuests.js",
        "css/pages/rank-history.css": "css/pages/rank-history.css",
        "css/pages/weekly-quests.css": "css/pages/weekly-quests.css",
        "migrations/0004_rank_history_quests.sql": "migrations/0004_rank_history_quests.sql",
    }
    for source_name, destination_name in mapping.items():
        source = payload / source_name
        if not source.is_file():
            fail(f'upgrade package is missing {source_name}.')
        destination = ROOT / destination_name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)


def install(payload: Path) -> None:
    # Patch points that depend on the current app structure first. Copy new assets only
    # after markers are validated to avoid leaving a half-integrated feature behind.
    for required in [ROOT / "worker.js", ROOT / "js/routes.js", ROOT / "index.html", ROOT / "wrangler.jsonc"]:
        if not required.is_file():
            fail(f'expected repository file missing: {required.relative_to(ROOT)}')
    worker_text = read_text(ROOT / "worker.js")
    routes_text = read_text(ROOT / "js/routes.js")
    html_text = read_text(ROOT / "index.html")
    if "handleRankHistoryQuestRequest" not in worker_text and "            // Register an account." not in worker_text:
        fail('worker.js structure is different from the supported repository version.')
    if "path: '/history'" not in routes_text and "    { path: '/achievements', component: Achievements }," not in routes_text:
        fail('js/routes.js structure is different from the supported repository version.')
    if 'to="/history"' not in html_text and 'to="/achievements"' not in html_text:
        fail('index.html navigation structure is different from the supported repository version.')

    copy_payload(payload)
    patch_worker()
    patch_routes()
    patch_html()
    patch_wrangler()
    patch_assetsignore()
    print("Rank History + Weekly Quests integration completed.")
    print("Before deploying, apply migrations/0004_rank_history_quests.sql to the existing remote D1 database.")
    print("The daily snapshot cron is configured for 00:00 UTC.")


ROOT = Path.cwd()

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="repository root")
    parser.add_argument("--payload", type=Path, required=True, help="payload folder from upgrade package")
    args = parser.parse_args()
    global ROOT
    ROOT = args.root.resolve()
    payload = args.payload.resolve()
    if not ROOT.is_dir(): fail("repository root folder does not exist")
    if not payload.is_dir(): fail("payload folder does not exist")
    install(payload)

if __name__ == "__main__":
    main()

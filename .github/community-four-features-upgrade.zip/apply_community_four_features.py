#!/usr/bin/env python3
"""Integrate the Suberboys Community Competition update into an existing checkout."""
from __future__ import annotations
import argparse
import json
import re
import shutil
from pathlib import Path


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"Cannot safely update {label}: expected one anchor, found {count}.")
    return text.replace(old, new, 1)


def copy_file(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)



def strip_json_comments(text: str) -> str:
    """Remove // and /* */ comments without touching comment-like text in strings."""
    out = []
    index = 0
    in_string = False
    escaped = False
    while index < len(text):
        char = text[index]
        if in_string:
            out.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            index += 1
            continue
        if char == '"':
            in_string = True
            out.append(char)
            index += 1
            continue
        if text.startswith("//", index):
            newline = text.find("\n", index + 2)
            if newline < 0:
                break
            out.append("\n")
            index = newline + 1
            continue
        if text.startswith("/*", index):
            end = text.find("*/", index + 2)
            if end < 0:
                raise SystemExit("wrangler.jsonc contains an unterminated block comment.")
            # Preserve line count for clearer diagnostics if parsing fails later.
            out.extend("\n" for char in text[index:end + 2] if char == "\n")
            index = end + 2
            continue
        out.append(char)
        index += 1
    return "".join(out)


def strip_json_trailing_commas(text: str) -> str:
    """Remove JSONC trailing commas outside strings (Wrangler accepts these)."""
    out = []
    index = 0
    in_string = False
    escaped = False
    while index < len(text):
        char = text[index]
        if in_string:
            out.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            index += 1
            continue
        if char == '"':
            in_string = True
            out.append(char)
            index += 1
            continue
        if char == ",":
            lookahead = index + 1
            while lookahead < len(text) and text[lookahead].isspace():
                lookahead += 1
            if lookahead < len(text) and text[lookahead] in "]}":
                index += 1
                continue
        out.append(char)
        index += 1
    return "".join(out)


def patch_wrangler(root: Path) -> None:
    path = root / "wrangler.jsonc"
    original = path.read_text(encoding="utf-8")
    try:
        config = json.loads(strip_json_trailing_commas(strip_json_comments(original)))
    except json.JSONDecodeError as error:
        raise SystemExit(f"Could not safely parse wrangler.jsonc: {error}")
    if not isinstance(config, dict):
        raise SystemExit("wrangler.jsonc must contain a JSON object.")
    d1_bindings = config.get("d1_databases", [])
    if not isinstance(d1_bindings, list) or not any(
        isinstance(item, dict) and item.get("binding") == "db" for item in d1_bindings
    ):
        raise SystemExit('wrangler.jsonc is missing the existing D1 binding "db".')
    assets = config.get("assets")
    if not isinstance(assets, dict) or assets.get("binding") != "ASSETS":
        raise SystemExit('wrangler.jsonc is missing the existing assets binding "ASSETS".')

    # The site now stores avatars in D1, so no R2 binding is needed. Also remove the
    # unsupported setting that produced a Wrangler warning in the user's deployment log.
    config.pop("r2_buckets", None)
    observability = config.get("observability")
    if isinstance(observability, dict):
        observability.pop("issue_detection", None)

    triggers = config.setdefault("triggers", {})
    if not isinstance(triggers, dict):
        raise SystemExit("wrangler.jsonc has an invalid triggers setting; expected an object.")
    crons = triggers.setdefault("crons", [])
    if not isinstance(crons, list):
        raise SystemExit("wrangler.jsonc triggers.crons must be an array.")
    if "0 0 * * *" not in crons:
        crons.append("0 0 * * *")

    updated = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
    if updated != original:
        path.write_text(updated, encoding="utf-8", newline="\n")


def patch_assetsignore(root: Path) -> None:
    path = root / ".assetsignore"
    existing = path.read_text(encoding="utf-8") if path.is_file() else ""
    lines = existing.splitlines()
    required = [
        ".git/", ".github/", ".wrangler/", "worker.js",
        "submission-routes.js", "rank-history-quests-worker.js",
        "community-features-worker.js", "wrangler.jsonc", "migrations/", ".assetsignore"
    ]
    for item in required:
        if item not in lines:
            lines.append(item)
    updated = "\n".join(lines).rstrip() + "\n"
    if updated != existing:
        path.write_text(updated, encoding="utf-8", newline="\n")

def integrate(root: Path, payload: Path) -> None:
    files = [
        ("community-features-worker.js", "community-features-worker.js"),
        ("js/pages/Clans.js", "js/pages/Clans.js"),
        ("js/pages/CommunityActivity.js", "js/pages/CommunityActivity.js"),
        ("js/pages/PlayerBattles.js", "js/pages/PlayerBattles.js"),
        ("js/pages/HallOfFame.js", "js/pages/HallOfFame.js"),
        ("css/pages/community-features.css", "css/pages/community-features.css"),
        ("migrations/0005_community_features.sql", "migrations/0005_community_features.sql"),
    ]
    for source_rel, target_rel in files:
        source = payload / source_rel
        if not source.is_file():
            raise SystemExit(f"Required package file is missing: {source_rel}")
        copy_file(source, root / target_rel)

    # Add frontend page imports and routes without replacing existing routes.
    routes_path = root / "js/routes.js"
    routes = routes_path.read_text(encoding="utf-8")
    imports = [
        ("import Clans from './pages/Clans.js';", "import WeeklyQuests from './pages/WeeklyQuests.js';"),
        ("import CommunityActivity from './pages/CommunityActivity.js';", "import Clans from './pages/Clans.js';"),
        ("import PlayerBattles from './pages/PlayerBattles.js';", "import CommunityActivity from './pages/CommunityActivity.js';"),
        ("import HallOfFame from './pages/HallOfFame.js';", "import PlayerBattles from './pages/PlayerBattles.js';"),
    ]
    for new_import, anchor in imports:
        if new_import not in routes:
            if anchor not in routes:
                raise SystemExit(f"Can't find frontend import anchor in js/routes.js: {anchor}")
            routes = routes.replace(anchor, anchor + "\n" + new_import, 1)
    route_lines = [
        "    { path: '/clans', component: Clans },",
        "    { path: '/clans/:id', component: Clans },",
        "    { path: '/activity', component: CommunityActivity },",
        "    { path: '/compare', component: PlayerBattles },",
        "    { path: '/hall-of-fame', component: HallOfFame },",
    ]
    if "{ path: '/clans', component: Clans }," not in routes:
        anchor = "    { path: '/quests', component: WeeklyQuests },"
        if anchor not in routes:
            raise SystemExit("Can't find /quests route in js/routes.js.")
        routes = routes.replace(anchor, anchor + "\n" + "\n".join(route_lines), 1)
    else:
        # Add any routes that are missing if a previous attempt partially applied.
        anchor = "    { path: '/quests', component: WeeklyQuests },"
        for line in route_lines:
            if line not in routes:
                if anchor not in routes:
                    raise SystemExit("Can't find /quests route in js/routes.js.")
                routes = routes.replace(anchor, anchor + "\n" + line, 1)
                anchor = line
    routes_path.write_text(routes, encoding="utf-8")

    # Add one stylesheet used by all four pages.
    index_path = root / "index.html"
    index = index_path.read_text(encoding="utf-8")
    css_link = '        <link rel="stylesheet" href="/css/pages/community-features.css" />'
    if css_link not in index:
        anchor = '        <link rel="stylesheet" href="/css/pages/weekly-quests.css" />'
        if anchor not in index:
            anchor = '        <link rel="stylesheet" href="/css/pages/player-showcase.css" />'
        if anchor not in index:
            raise SystemExit("Can't find a stylesheet anchor in index.html.")
        index = index.replace(anchor, anchor + "\n" + css_link, 1)

    # Add links after Quests but before Profile, preserving the project's current nav markup.
    nav_links = [
        '''                <router-link class="nav__tab" to="/clans"><span class="type-label-lg">Clans</span></router-link>''',
        '''                <router-link class="nav__tab" to="/activity"><span class="type-label-lg">Activity</span></router-link>''',
        '''                <router-link class="nav__tab" to="/compare"><span class="type-label-lg">Compare</span></router-link>''',
        '''                <router-link class="nav__tab" to="/hall-of-fame"><span class="type-label-lg">Hall of Fame</span></router-link>''',
    ]
    def nav_target(line: str) -> str:
        match = re.search(r'to="([^"]+)"', line)
        if not match:
            raise SystemExit(f"Internal error: nav link is missing a route: {line}")
        return match.group(1)

    missing_links = [line for line in nav_links if f'to="{nav_target(line)}"' not in index]
    if missing_links:
        quests_pattern = re.compile(r'(<router-link\b[^>]*to="/quests"[^>]*>.*?</router-link>)', re.S)
        match = quests_pattern.search(index)
        if not match:
            raise SystemExit("Can't find the Quests link in index.html.")
        index = index[:match.end()] + "\n" + "\n".join(missing_links) + index[match.end():]
    index_path.write_text(index, encoding="utf-8")

    # Wire the module into the Worker API router.
    worker_path = root / "worker.js"
    worker = worker_path.read_text(encoding="utf-8")
    community_import = 'import { handleCommunityRequest, captureCommunitySnapshot, ensureCommunitySchema } from "./community-features-worker.js";'
    old_community_import = 'import { handleCommunityRequest, captureCommunitySnapshot } from "./community-features-worker.js";'
    if community_import not in worker:
        if old_community_import in worker:
            worker = worker.replace(old_community_import, community_import, 1)
        else:
            anchor = 'import { handleRankHistoryQuestRequest, captureDailyRankSnapshot } from "./rank-history-quests-worker.js";'
            if anchor in worker:
                worker = worker.replace(anchor, anchor + "\n" + community_import, 1)
            else:
                anchor = 'import { handleSubmissionRoute } from "./submission-routes.js";'
                if anchor not in worker:
                    raise SystemExit("Can't find Worker import anchor in worker.js.")
                worker = worker.replace(anchor, anchor + "\n" + community_import, 1)

    dispatch_anchor = '''            const rankHistoryQuestResponse = await handleRankHistoryQuestRequest(
                request, env, url, currentUser
            );
            if (rankHistoryQuestResponse) return rankHistoryQuestResponse;'''
    schema_bootstrap = '''            if (
                url.pathname.startsWith("/api/community/") ||
                url.pathname === "/api/rank-history" ||
                url.pathname === "/api/weekly-quests"
            ) {
                await ensureCommunitySchema(env);
            }
'''
    if 'url.pathname.startsWith("/api/community/")' not in worker:
        worker = replace_once(worker, dispatch_anchor, schema_bootstrap + dispatch_anchor, "D1 schema bootstrap")
    community_dispatch = '''            const communityResponse = await handleCommunityRequest(request, env, url, currentUser);
            if (communityResponse) return communityResponse;'''
    if "handleCommunityRequest(request, env, url, currentUser)" not in worker:
        worker = replace_once(worker, dispatch_anchor, dispatch_anchor + "\n" + community_dispatch, "worker route dispatch")

    # Extend the current daily snapshot job so the permanent Hall of Fame and
    # historical community feed are captured from the same UTC-day snapshot.
    if "captureCommunitySnapshot(env, snapshotTime, false)" not in worker:
        pattern = re.compile(
            r"    async scheduled\(controller, env, ctx\) \{\n"
            r"        ctx\.waitUntil\(\n"
            r"            captureDailyRankSnapshot\(env, new Date\(controller\.scheduledTime\)\)\.catch\(error => \{\n"
            r"                console\.error\(\"Daily rank-history snapshot failed:\", error\?\.stack \|\| error\);\n"
            r"            \}\)\n        \);\n    \}"
        )
        replacement = """    async scheduled(controller, env, ctx) {
        const snapshotTime = new Date(controller.scheduledTime);
        ctx.waitUntil((async () => {
            await ensureCommunitySchema(env);
            await captureDailyRankSnapshot(env, snapshotTime);
            await captureCommunitySnapshot(env, snapshotTime, false);
        })().catch(error => {
            console.error("Daily rank/community snapshot failed:", error?.stack || error);
        }));
    }"""
        worker, n = pattern.subn(replacement, worker, count=1)
        if n != 1:
            raise SystemExit("Can't safely extend the scheduled snapshot handler in worker.js. No partial install should be committed.")

    worker_path.write_text(worker, encoding="utf-8")
    patch_wrangler(root)
    patch_assetsignore(root)
    print("Integrated clans, activity, player battles and Hall of Fame.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--payload", required=True, type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    payload = args.payload.resolve()
    for expected in ("worker.js", "js/routes.js", "index.html", "wrangler.jsonc"):
        if not (root / expected).is_file():
            raise SystemExit(f"Repository root is missing {expected}.")
    integrate(root, payload)

if __name__ == "__main__":
    main()

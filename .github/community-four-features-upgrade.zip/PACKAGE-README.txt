SUBERBOYS DEMON LIST — COMMUNITY COMPETITION UPDATE
===================================================

This update adds four features in one install:
  1. Real clans: create a clan, request to join, approve requests, manage roles,
     remove members, leave or disband a clan, and rank clans by linked members' points.
  2. Community activity feed: daily leaderboard rank/points/record changes plus clan events.
  3. Player Battles: compare two leaderboard players' points, records, hardest levels,
     shared completions, and share the matchup using the URL.
  4. Hall of Fame: daily Top 10 archive, #1 days, longest consecutive #1 streak,
     peak points, best rank, and recent champions.

NO TERMINAL AND NO R2 BUCKET REQUIRED
------------------------------------
This package is installed through GitHub Actions from the GitHub website. It uses the
existing Cloudflare D1 database and the existing static assets/Worker. The Worker will
create the required tables when the feature endpoints are first used. The migration file
is also committed to the repo for schema history; you do not need to paste SQL into D1.

INSTALL USING THE GITHUB WEBSITE
--------------------------------
1. Download and extract the OUTER ZIP on your PC.
2. In your GitHub repo, open the .github folder. Choose Add file > Upload files.
   Upload community-four-features-upgrade.zip (the INNER ZIP from this package) into
   this folder, then commit to main. The repository path must be:
       .github/community-four-features-upgrade.zip
3. Open .github/workflows. Choose Add file > Upload files. Upload
   install-community-features.yml from this package, then commit it to main.
   The destination must be:
       .github/workflows/install-community-features.yml
4. Open the repository's Actions tab and select "Install Community Features".
5. Click Run workflow. Leave the branch set to main. Toggle Confirm install to true,
   then click the green Run workflow button.
6. If the run succeeds, the workflow commits the app changes to main. Cloudflare should
   deploy the new Worker and static assets from that commit.
7. After deployment, refresh the site with Ctrl+F5 and open:
       /clans
       /activity
       /compare
       /hall-of-fame

WHAT THE WORKFLOW CHANGES
-------------------------
It adds four Vue pages, a shared stylesheet and Worker API routes. It adds links to the
existing navigation after Quests, keeps the current pages intact, extends the existing
daily snapshot cron for the Hall of Fame, bootstraps rank-history/quest and community
D1 tables safely, and adds migration 0005. It does not overwrite worker.js wholesale.

IMPORTANT NOTES
---------------
- You need an existing logged-in account linked to a leaderboard identity to create or
  join a clan. Each account can belong to one clan or have one pending request at a time.
- Clan membership changes use requests; clan leaders/officers can approve and reject.
- The activity feed starts with events detected from the first snapshots after install.
- The Hall of Fame does not invent historical records. It starts collecting true daily
  records after install and builds up as snapshots run.
- The worker uses the existing daily rank-history snapshot function and existing points
  formula. The update does not add an R2 binding or a new paid storage provider.
- The installer checks syntax and SQL using a repository checkout; it does not deploy
  directly to Cloudflare. Your normal Cloudflare deploy starts after the commit is pushed.

IF THE WORKFLOW FAILS
---------------------
Open Actions > Install Community Features, click the failed run, and expand the first red
step. Send the error from that step. If failure happens at Commit integration, check that
the Actions workflow is allowed to write to the repository and that main has no branch
protection rule blocking direct pushes from GitHub Actions.

import { fetchList } from '../content.js';
import { PACK_DEFINITIONS } from '../packs.js';
import { isHalloweenEventActive } from '../event-schedule.js';

const PAGE_ITEMS = [
    { id: 'page:list', type: 'page', title: 'Demon List', subtitle: 'Browse ranked levels', path: '/', keywords: 'home levels records list' },
    { id: 'page:leaderboard', type: 'page', title: 'Leaderboard', subtitle: 'Players and points', path: '/leaderboard', keywords: 'rank rankings points' },
    { id: 'page:games', type: 'page', title: 'Games', subtitle: 'Mini-games', path: '/games', keywords: 'play roulette higher lower' },
    { id: 'page:packs', type: 'page', title: 'Packs', subtitle: 'Level packs and victors', path: '/packs', keywords: 'pack bundles bonus' },
    { id: 'page:achievements', type: 'page', title: 'Achievements', subtitle: 'Milestones and tiers', path: '/achievements', keywords: 'badges bronze silver gold diamond platinum legendary' },
    { id: 'page:history', type: 'page', title: 'Rank History', subtitle: 'Past list rankings', path: '/history', keywords: 'time travel archive snapshots history' },
    { id: 'page:quests', type: 'page', title: 'Weekly Quests', subtitle: 'Goals and secret achievements', path: '/quests', keywords: 'weekly quest challenge secret' },
    { id: 'page:clans', type: 'page', title: 'Clans', subtitle: 'Community teams', path: '/clans', keywords: 'team members clan ranking' },
    { id: 'page:activity', type: 'page', title: 'Community Activity', subtitle: 'Recent site events', path: '/activity', keywords: 'feed news events' },
    { id: 'page:compare', type: 'page', title: 'Player Compare', subtitle: 'Compare two players', path: '/compare', keywords: 'battle versus versus stats' },
    { id: 'page:hall-of-fame', type: 'page', title: 'Hall of Fame', subtitle: 'Historic leaders and records', path: '/hall-of-fame', keywords: 'champions legends #1' },
    { id: 'page:profile', type: 'page', title: 'Profile', subtitle: 'Your account and customisation', path: '/profile', keywords: 'avatar frame nationality bio clan settings' },
    { id: 'page:submit', type: 'page', title: 'Submit Record', subtitle: 'Submit a level record', path: '/submit', keywords: 'verification completion proof' },
    { id: 'page:admin', type: 'page', title: 'Admin Panel', subtitle: 'Site administration', path: '/admin', keywords: 'manage accounts tools', adminOnly: true },
    { id: 'page:login', type: 'page', title: 'Log In', subtitle: 'Sign in to your account', path: '/login', keywords: 'sign in authentication' },
    { id: 'page:register', type: 'page', title: 'Create Account', subtitle: 'Register a new account', path: '/register', keywords: 'sign up registration' },
];

let sharedIndex = null;
let sharedIndexPromise = null;

function normalise(value) {
    return String(value || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('en').trim();
}

function editableTarget(target) {
    if (!(target instanceof Element)) return false;
    return Boolean(target.closest('input, textarea, select, [contenteditable="true"], [role="textbox"]'));
}

async function buildIndex() {
    const items = PAGE_ITEMS.map(item => ({ ...item }));
    const names = new Set();

    try {
        const list = await fetchList();
        if (Array.isArray(list)) {
            list.forEach(([level, error], index) => {
                if (error || !level) return;
                const rank = index + 1;
                const name = String(level.name || '').trim();
                const path = String(level.path || '').trim();
                if (name) {
                    items.push({
                        id: `level:${path || name}`,
                        type: 'level',
                        title: name,
                        subtitle: `Level #${rank}`,
                        key: path || name,
                        keywords: `${path} ${level.verifier || ''}`,
                    });
                }
                if (typeof level.verifier === 'string' && level.verifier.trim()) names.add(level.verifier.trim());
                for (const record of Array.isArray(level.records) ? level.records : []) {
                    if (record && typeof record.user === 'string' && record.user.trim()) names.add(record.user.trim());
                }
            });
        }
    } catch (error) {
        console.warn('Quick search could not index levels.', error);
    }

    try {
        const response = await fetch('/api/leaderboard/identities', {
            credentials: 'same-origin',
            cache: 'no-store',
        });
        if (response.ok) {
            const data = await response.json();
            if (Array.isArray(data.identities)) {
                for (const name of data.identities) {
                    if (typeof name === 'string' && name.trim()) names.add(name.trim());
                }
            }
        }
    } catch (error) {
        console.warn('Quick search could not load linked player names.', error);
    }

    for (const name of [...names].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))) {
        items.push({
            id: `player:${normalise(name)}`,
            type: 'player',
            title: name,
            subtitle: 'Player profile',
            key: name,
            keywords: 'leaderboard points records profile',
        });
    }

    const halloweenActive = isHalloweenEventActive();
    for (const pack of PACK_DEFINITIONS) {
        if (pack.id === 'spooky' && !halloweenActive) continue;
        items.push({
            id: `pack:${pack.id}`,
            type: 'pack',
            title: pack.name,
            subtitle: `${pack.category || 'Pack'} pack · ${pack.bonus || 0} bonus points`,
            key: pack.id,
            keywords: `${pack.category || ''} pack bonus levels`,
        });
    }

    return items;
}

export default {
    name: 'SiteSearch',
    data() {
        return {
            open: false,
            query: '',
            loadingIndex: false,
            indexReady: false,
            indexItems: PAGE_ITEMS.map(item => ({ ...item })),
            activeIndex: 0,
            error: '',
        };
    },
    computed: {
        results() {
            const query = normalise(this.query);
            if (!query) {
                return this.indexItems.filter(item => item.type === 'page').slice(0, 8);
            }
            return this.indexItems
                .map(item => {
                    const title = normalise(item.title);
                    const haystack = normalise(`${item.title} ${item.subtitle || ''} ${item.keywords || ''}`);
                    if (!haystack.includes(query)) return null;
                    const score = title === query ? 0 : title.startsWith(query) ? 1 : title.includes(query) ? 2 : 3;
                    return { ...item, score };
                })
                .filter(Boolean)
                .sort((a, b) => a.score - b.score || a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }))
                .slice(0, 16);
        },
    },
    template: `
        <div class="site-search-root">
            <button type="button" class="site-search-trigger nav__icon" @click="toggle"
                aria-label="Search the site" title="Search the site (Ctrl+K)">
                <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"></circle><path d="m16 16 4.3 4.3"></path></svg>
            </button>
            <div v-if="open" class="site-search-overlay" @click.self="close">
                <section class="site-search-dialog" role="dialog" aria-modal="true" aria-label="Search Suberboys Demon List">
                    <div class="site-search-input-wrap">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"></circle><path d="m16 16 4.3 4.3"></path></svg>
                        <input ref="searchInput" v-model="query" type="search" autocomplete="off" spellcheck="false"
                            placeholder="Search levels, players, packs or pages…"
                            aria-label="Search levels, players, packs or pages"
                            @input="activeIndex = 0"
                            @keydown.down.prevent="moveActive(1)"
                            @keydown.up.prevent="moveActive(-1)"
                            @keydown.enter.prevent="selectActive"
                            @keydown.esc.prevent="close" />
                        <kbd>ESC</kbd>
                    </div>
                    <div class="site-search-subtitle">QUICK SEARCH <span>Ctrl K</span></div>
                    <p v-if="loadingIndex" class="site-search-state">Indexing levels and players…</p>
                    <p v-else-if="error" class="site-search-state">{{ error }}</p>
                    <p v-else-if="query.trim() && !results.length" class="site-search-state">No matches. Try a shorter search.</p>
                    <div v-else class="site-search-results" role="listbox" aria-label="Search results">
                        <button v-for="(item, index) in results" :key="item.id" type="button"
                            class="site-search-result" :class="{ 'is-active': activeIndex === index }"
                            role="option" :aria-selected="activeIndex === index"
                            @mouseenter="activeIndex = index" @click="selectResult(item)">
                            <span class="site-search-result-type" :class="'type-' + item.type">{{ item.type }}</span>
                            <span class="site-search-result-copy"><strong>{{ item.title }}</strong><small>{{ item.subtitle }}</small></span>
                            <span class="site-search-result-enter" aria-hidden="true">↵</span>
                        </button>
                    </div>
                    <footer class="site-search-footer"><span>↑ ↓ to navigate</span><span>Enter to open</span><span>Esc to close</span></footer>
                </section>
            </div>
        </div>
    `,
    mounted() {
        this.globalKeyHandler = event => {
            const key = String(event.key || '').toLowerCase();
            if ((event.ctrlKey || event.metaKey) && key === 'k') {
                event.preventDefault();
                this.openPalette();
                return;
            }
            if (key === '/' && !event.ctrlKey && !event.metaKey && !event.altKey && !editableTarget(event.target)) {
                event.preventDefault();
                this.openPalette();
                return;
            }
            if (key === 'escape' && this.open) this.close();
        };
        document.addEventListener('keydown', this.globalKeyHandler);
    },
    beforeUnmount() {
        if (this.globalKeyHandler) document.removeEventListener('keydown', this.globalKeyHandler);
    },
    methods: {
        async toggle() {
            if (this.open) return this.close();
            return this.openPalette();
        },
        async openPalette() {
            this.open = true;
            this.activeIndex = 0;
            this.error = '';
            this.$nextTick(() => this.$refs.searchInput?.focus());
            if (!this.indexReady) await this.loadIndex();
        },
        close() {
            this.open = false;
            this.query = '';
            this.activeIndex = 0;
        },
        async loadIndex() {
            if (sharedIndex) {
                this.indexItems = sharedIndex;
                this.indexReady = true;
                return;
            }
            if (!sharedIndexPromise) sharedIndexPromise = buildIndex();
            this.loadingIndex = true;
            this.error = '';
            try {
                sharedIndex = await sharedIndexPromise;
                this.indexItems = sharedIndex;
                this.indexReady = true;
            } catch (error) {
                sharedIndexPromise = null;
                this.error = 'Could not load searchable site content. Pages are still available below when you clear the search.';
                console.error('Quick search index failed.', error);
            } finally {
                this.loadingIndex = false;
            }
        },
        moveActive(delta) {
            if (!this.results.length) return;
            this.activeIndex = (this.activeIndex + delta + this.results.length) % this.results.length;
        },
        selectActive() {
            const item = this.results[this.activeIndex];
            if (item) this.selectResult(item);
        },
        async selectResult(item) {
            this.close();
            const router = this.$router;
            if (!router || !item) return;
            try {
                if (item.type === 'page') {
                    if (router.currentRoute.value.path !== item.path) await router.push(item.path);
                    return;
                }
                if (item.type === 'player') {
                    await router.push(`/players/${encodeURIComponent(item.key)}`);
                    return;
                }
                if (item.type === 'level') {
                    await router.push({ path: '/', query: { quickSearchLevel: item.key } });
                    return;
                }
                if (item.type === 'pack') {
                    await router.push({ path: '/packs', query: { quickSearchPack: item.key } });
                }
            } catch (error) {
                console.warn('Could not navigate to quick search result.', error);
            }
        },
    },
};

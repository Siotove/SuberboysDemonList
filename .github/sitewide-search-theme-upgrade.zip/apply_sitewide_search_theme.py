#!/usr/bin/env python3
"""Idempotently add site-wide quick search and robust seasonal-theme cleanup."""
from __future__ import annotations
import argparse
import re
import shutil
from pathlib import Path


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"Expected exactly one integration anchor in {label}; found {count}: {old[:100]!r}")
    return text.replace(old, new, 1)


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def copy_payload(root: Path, payload: Path) -> None:
    if not payload.is_dir():
        raise SystemExit(f"Payload folder not found: {payload}")
    for source in payload.rglob("*"):
        if not source.is_file():
            continue
        target = root / source.relative_to(payload)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and target.read_bytes() == source.read_bytes():
            continue
        shutil.copy2(source, target)


def patch_index(root: Path) -> None:
    path = root / "index.html"
    text = path.read_text(encoding="utf-8")
    search_css = '<link rel="stylesheet" type="text/css" href="/css/components/site-search.css" />'
    if search_css not in text:
        anchor = '<link rel="stylesheet" type="text/css" href="/css/components/competition-platform.css" />'
        text = replace_once(text, anchor, search_css + "\n        " + anchor, str(path))
    if '<site-search></site-search>' not in text:
        anchor = '                    <notifications-bell></notifications-bell>'
        text = replace_once(text, anchor, '                    <site-search></site-search>\n' + anchor, str(path))
    write_text(path, text)


def patch_main(root: Path) -> None:
    path = root / "js/main.js"
    text = path.read_text(encoding="utf-8")
    import_line = "import SiteSearch from './components/SiteSearch.js';"
    if import_line not in text:
        anchor = "import CompetitionAdminTools from './components/CompetitionAdminTools.js';"
        text = replace_once(text, anchor, anchor + "\n" + import_line, str(path))

    registration = "app.component('site-search', SiteSearch);"
    if registration not in text:
        anchor = "app.component('competition-admin-tools', CompetitionAdminTools);"
        text = replace_once(text, anchor, anchor + "\n" + registration, str(path))

    if "halloween-theme-active" not in text:
        pattern = re.compile(r"function updateHalloweenTheme\(\) \{.*?^\}", re.S | re.M)
        matches = list(pattern.finditer(text))
        if len(matches) != 1:
            raise SystemExit(f"Could not safely locate updateHalloweenTheme() in {path}.")
        replacement = '''function updateHalloweenTheme() {
    const active = isHalloweenEventActive(new Date());
    store.halloween = active;

    // The event theme is class-driven only. Removing these classes restores
    // the normal variables and styles immediately when the window closes.
    document.body.classList.toggle('halloween-theme', active);
    document.documentElement.classList.toggle('halloween-theme-active', active);
}
'''
        m = matches[0]
        text = text[:m.start()] + replacement.rstrip() + text[m.end():]

    if "halloweenThemeVisibilityHandler" not in text:
        old_lifecycle = '''    mounted() {
        updateHalloweenTheme();
        this.halloweenTimer = setInterval(
            updateHalloweenTheme,
            60 * 1000
        );
    },

    beforeUnmount() {
        clearInterval(this.halloweenTimer);
    },'''
        new_lifecycle = '''    mounted() {
        updateHalloweenTheme();
        // Refresh frequently and whenever a background tab becomes active,
        // so the event styling cannot remain stuck after its end time.
        this.halloweenTimer = setInterval(updateHalloweenTheme, 15 * 1000);
        this.halloweenFocusHandler = () => updateHalloweenTheme();
        this.halloweenThemeVisibilityHandler = () => {
            if (!document.hidden) updateHalloweenTheme();
        };
        window.addEventListener('focus', this.halloweenFocusHandler);
        document.addEventListener('visibilitychange', this.halloweenThemeVisibilityHandler);
    },

    beforeUnmount() {
        if (this.halloweenTimer) clearInterval(this.halloweenTimer);
        if (this.halloweenFocusHandler) window.removeEventListener('focus', this.halloweenFocusHandler);
        if (this.halloweenThemeVisibilityHandler) {
            document.removeEventListener('visibilitychange', this.halloweenThemeVisibilityHandler);
        }
    },'''
        text = replace_once(text, old_lifecycle, new_lifecycle, str(path))

    text = text.replace("\n// hallnoween\nupdateHalloweenTheme();\n", "\nupdateHalloweenTheme();\n")
    write_text(path, text)


def patch_main_theme_dark_mode(root: Path) -> None:
    path = root / "css/main.css"
    text = path.read_text(encoding="utf-8")
    if "body.halloween-theme header.dark" in text:
        return
    block = '''
/* Ensure seasonal variables override local dark-mode variables, then disappear at event end. */
body.halloween-theme header.dark,
body.halloween-theme main.dark {
    --color-background: #100d18;
    --color-on-background: #f2eafa;
    --color-background-hover: #30213f;
    --color-on-background-hover: #ffffff;
    --color-primary: #7b2cbf;
    --color-on-primary: #ffffff;
    --color-primary-disabled: #49315e;
    --color-error: #ff6b6b;
    --color-on-error: #ffffff;
    --border-subtle: #49315e;
    --surface-muted: #1b1426;
    --surface-raised: #261a35;
    color-scheme: dark;
}
'''
    write_text(path, text.rstrip() + "\n" + block)


def patch_theme_tokens(root: Path) -> None:
    path = root / "css/components/competition-platform.css"
    text = path.read_text(encoding="utf-8")
    variable_block = '''\n/* Theme-aware accents: seasonal colours are only active while body.halloween-theme is present. */
:root {
    --competition-accent: var(--color-primary, #0066ff);
    --competition-accent-strong: var(--color-primary, #0066ff);
    --competition-accent-soft: var(--surface-muted, rgba(0, 102, 255, .08));
    --competition-border: var(--border-subtle, rgba(0, 0, 0, .18));
    --competition-border-soft: var(--border-subtle, rgba(0, 0, 0, .12));
}
header.dark, main.dark {
    --competition-accent: var(--color-primary, #283593);
    --competition-accent-strong: var(--color-primary, #283593);
    --competition-accent-soft: rgba(255, 255, 255, .07);
    --competition-border: var(--border-subtle, rgba(255, 255, 255, .16));
    --competition-border-soft: rgba(255, 255, 255, .12);
}
body.halloween-theme,
body.halloween-theme header.dark,
body.halloween-theme main.dark {
    --competition-accent: var(--halloween-purple, #a66bdf);
    --competition-accent-strong: var(--halloween-orange, #ff8c2a);
    --competition-accent-soft: rgba(168, 107, 223, .12);
    --competition-border: var(--halloween-border, #49315e);
    --competition-border-soft: rgba(166, 107, 223, .22);
}
'''
    if "--competition-accent-soft:" not in text:
        first_newline = text.find("\n")
        if first_newline == -1:
            raise SystemExit(f"Could not safely insert theme variables into {path}.")
        text = text[:first_newline + 1] + variable_block + text[first_newline + 1:]

    # Replace fixed purple/orange decorations with semantic tokens, so they
    # follow the current site palette after the seasonal class is removed.
    substitutions = {
        "border:1px solid rgba(184,115,230,.4)": "border:1px solid var(--competition-border)",
        "background:rgba(168,85,247,.12)": "background:var(--competition-accent-soft)",
        "background:#a855f7": "background:var(--competition-accent)",
        "background:#ff7b22": "background:var(--competition-accent-strong)",
        "background:rgba(100,48,128,.12)": "background:var(--competition-accent-soft)",
        "background:rgba(100,48,128,.1)": "background:var(--competition-accent-soft)",
        "border:1px solid rgba(168,85,247,.4)": "border:1px solid var(--competition-border)",
        "border:1px solid rgba(168,85,247,.45)": "border:1px solid var(--competition-border)",
        "border:1px solid rgba(168,85,247,.5)": "border:1px solid var(--competition-border)",
        "border:1px solid rgba(168,85,247,.32)": "border:1px solid var(--competition-border-soft)",
        "border:1px solid rgba(168,85,247,.35)": "border:1px solid var(--competition-border)",
        "border-top:1px solid rgba(168,85,247,.2)": "border-top:1px solid var(--competition-border-soft)",
        "border-top:1px solid rgba(168,85,247,.18)": "border-top:1px solid var(--competition-border-soft)",
        "border:1px solid rgba(168,85,247,.18)": "border:1px solid var(--competition-border-soft)",
        "border:1px solid rgba(168,85,247,.22)": "border:1px solid var(--competition-border-soft)",
        "border:1px solid rgba(168,85,247,.3)": "border:1px solid var(--competition-border-soft)",
        "border:1px solid rgba(168,85,247,.1)": "border:1px solid var(--competition-border-soft)",
        "background:rgba(168,85,247,.22)": "background:var(--competition-accent-soft)",
        "background:rgba(168,85,247,.1)": "background:var(--competition-accent-soft)",
        "background:rgba(168,85,247,.08)": "background:var(--competition-accent-soft)",
        "border-left:3px solid #a855f7": "border-left:3px solid var(--competition-accent)",
        "linear-gradient(90deg,#a855f7,#ff7b22)": "linear-gradient(90deg,var(--competition-accent),var(--competition-accent-strong))",
        "color:#ff9b40": "color:var(--competition-accent-strong)",
        "color:#ffc04d": "color:var(--competition-accent-strong)",
        "background:#d779ff": "background:var(--competition-accent)",
    }
    for old, new in substitutions.items():
        text = text.replace(old, new)

    # Category-specific notification colours remain meaningful; only the
    # default, clan, announcement and unread accents follow the site theme.
    text = text.replace(".competition-notice-dot.is-clan{background:#d779ff}", ".competition-notice-dot.is-clan{background:var(--competition-accent)}")
    text = text.replace(".competition-notice-dot.is-announcement{background:#ff7b22}", ".competition-notice-dot.is-announcement{background:var(--competition-accent-strong)}")
    write_text(path, text)


def patch_list_level_deep_link(root: Path) -> None:
    path = root / "js/pages/List.js"
    text = path.read_text(encoding="utf-8")
    watcher = '''    watch: {
        '$route.query.quickSearchLevel'(value) {
            if (value) this.applyQuickSearchLevel(String(value));
        },
    },

'''
    if "'$route.query.quickSearchLevel'" not in text:
        text = replace_once(text, "    computed: {\n", watcher + "    computed: {\n", str(path))
    if "applyQuickSearchLevel(target)" not in text:
        method = '''        applyQuickSearchLevel(target) {
            const levels = this.currentList || this.list || [];
            const index = levels.findIndex(([level]) => level && (
                String(level.path || '') === String(target) || String(level.name || '') === String(target)
            ));
            if (index < 0) return false;
            this.selected = index;
            const query = { ...this.$route.query };
            delete query.quickSearchLevel;
            this.$router.replace({ path: '/', query }).catch(() => {});
            return true;
        },

'''
        text = replace_once(text, "        formatDate(date) {\n", method + "        formatDate(date) {\n", str(path))
    if "this.applyQuickSearchLevel(String(this.$route.query.quickSearchLevel))" not in text:
        anchor = "        this.list = this.currentList;\n"
        addition = '''        this.list = this.currentList;
        if (this.$route?.query?.quickSearchLevel) {
            this.applyQuickSearchLevel(String(this.$route.query.quickSearchLevel));
        }
'''
        text = replace_once(text, anchor, addition, str(path))
    write_text(path, text)


def patch_packs_deep_link(root: Path) -> None:
    path = root / "js/pages/Packs.js"
    text = path.read_text(encoding="utf-8")
    watcher = '''    watch: {
        '$route.query.quickSearchPack'(value) {
            if (value) this.applyQuickSearchPack(String(value));
        },
    },
'''
    if "'$route.query.quickSearchPack'" not in text:
        text = replace_once(text, "    computed: {\n", watcher + "\n    computed: {\n", str(path))
    if "applyQuickSearchPack(target)" not in text:
        method = '''        applyQuickSearchPack(target) {
            const pack = this.packs.find(item => item.id === String(target) || item.name === String(target));
            if (!pack) return false;
            this.selectedCategory = pack.category || 'All';
            this.expandedPack = pack.id;
            const query = { ...this.$route.query };
            delete query.quickSearchPack;
            this.$router.replace({ path: '/packs', query }).catch(() => {});
            return true;
        },

'''
        text = replace_once(text, "        toggleVictors(packId) {\n", method + "        toggleVictors(packId) {\n", str(path))
    if "this.applyQuickSearchPack(String(this.$route.query.quickSearchPack))" not in text:
        anchor = "            });\n        } catch (error) {\n            console.error('Failed to load packs:', error);"
        addition = """            });
            if (this.$route?.query?.quickSearchPack) {
                this.applyQuickSearchPack(String(this.$route.query.quickSearchPack));
            }
        } catch (error) {
            console.error('Failed to load packs:', error);"""
        text = replace_once(text, anchor, addition, str(path))
    write_text(path, text)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default='.')
    parser.add_argument('--payload', required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    payload = Path(args.payload).resolve()
    required = [
        root / 'index.html', root / 'js/main.js', root / 'js/pages/List.js',
        root / 'js/pages/Packs.js', root / 'css/components/competition-platform.css', root / 'css/main.css',
        root / 'js/event-schedule.js',
    ]
    missing = [str(path.relative_to(root)) for path in required if not path.is_file()]
    if missing:
        raise SystemExit('Files required to safely install this update are missing: ' + ', '.join(missing))
    for required_payload in [payload / 'js/components/SiteSearch.js', payload / 'css/components/site-search.css']:
        if not required_payload.is_file():
            raise SystemExit('Payload is missing required file: ' + str(required_payload.relative_to(payload)))

    copy_payload(root, payload)
    patch_index(root)
    patch_main(root)
    patch_theme_tokens(root)
    patch_main_theme_dark_mode(root)
    patch_list_level_deep_link(root)
    patch_packs_deep_link(root)

    print('Installed site-wide quick search and seasonal theme cleanup.')
    print('Quick search: navbar button, Ctrl+K / / shortcut, levels, players, packs and pages.')
    print('Halloween theme: refreshes every 15 seconds and on focus/visibility; seasonal component accents reset with the event class.')
    print('No Worker route, D1 migration, or R2 bucket is required for this update.')

if __name__ == '__main__':
    main()

# Site-wide Search + Seasonal Theme Fix

The package contains `apply_sitewide_search_theme.py` and `payload/`. It is designed to be run by the included GitHub Actions workflow against the existing Suberboys Demon List repository. The theme patch also applies seasonal variables to dark-mode header/page roots only while the event class is active, so they revert naturally when the class is removed.

The installer copies the new SiteSearch component and CSS then idempotently patches `index.html`, `js/main.js`, `js/pages/List.js`, `js/pages/Packs.js` and `css/components/competition-platform.css`.

Run locally with:

```sh
python apply_sitewide_search_theme.py --root . --payload payload
```

No new page route, Worker API route, D1 migration or R2 bucket is required.
